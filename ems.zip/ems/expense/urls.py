from django.urls import path
from .views import *

urlpatterns = [
    # path('add/',add_expense.as_view(),name='add')
]