from django import forms
from.models import*

#class contactus_form(forms.ModelForm):
 #   class Meta:
  #      model =contact
   #     fields ='_all_'

class ProjectCreationForm(forms.ModelForm):
    class Meta:
        model =Expense
        fields ='__all__'